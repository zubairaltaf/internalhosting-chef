name 'lamp'
maintainer 'Karl Girthofer'
maintainer_email 'karlgirthofer@gmail.com'
license 'GNU GPL v3'
description 'Installs/Configures lamp server'
long_description 'Installs/Configures lamp server'
version '1.0.4'


supports 'amazon'

## depends on another cookbook, or series of cookbooks?
## depends 'some_cookbook'
#Cookbooks installed by your Berksfile:
